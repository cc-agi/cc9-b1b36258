# Sentinel OS - Desktop Operator local bridge (P0-R5)
# ASCII-only source, CRLF-enforced via .gitattributes.
#
# Runs an HTTP listener bound STRICTLY to 127.0.0.1:<random port> that
# authenticates every request with an ephemeral session bearer secret.
# Never binds a LAN interface. Never accepts arbitrary shell commands or
# eval; the tool switch is a closed whitelist that maps directly to
# user32 SendInput, .NET UIAutomation, and Windows.Forms clipboard.
#
# Session lifetime is capped by an idle TTL. The bridge exits when the
# TTL elapses without activity, or when stop-desktop-operator.bat requests it.
#
# NEVER bypasses UAC or the secure desktop. All actions run in the current
# interactive session with the current user's privileges.

param(
    [int]$IdleTtlSeconds = 1800,      # 30 minutes default
    [switch]$CiCheck                  # non-mutating preflight for CI
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

if ($CiCheck) {
    # Static, non-network, non-mutating preflight only.
    # Verify PowerShell version, .NET types are loadable, whitelist compiles.
    if ($PSVersionTable.PSVersion.Major -lt 5) {
        Write-Error "PowerShell 5.0+ required (found $($PSVersionTable.PSVersion))"
        exit 4
    }
    try { Add-Type -AssemblyName System.Windows.Forms | Out-Null } catch {
        Write-Error "System.Windows.Forms unavailable: $($_.Exception.Message)"
        exit 4
    }
    Write-Host "[desktop-operator] preflight OK (PowerShell $($PSVersionTable.PSVersion), .NET Forms loaded)."
    exit 0
}

if ($PSVersionTable.Platform -and $PSVersionTable.Platform -ne 'Win32NT') {
    Write-Error "Desktop Operator only runs on Windows."
    exit 3
}

# ---------- Paths & session state ----------
$appDataRoot = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { $env:APPDATA }
$sentinelDir = Join-Path $appDataRoot 'SentinelOS'
$logDir      = Join-Path $sentinelDir 'desktop-logs'
$sessionFile = Join-Path $sentinelDir 'desktop-session.json'
$pidFile     = Join-Path $sentinelDir 'desktop-operator.pid'
if (-not (Test-Path $sentinelDir)) { New-Item -ItemType Directory -Path $sentinelDir | Out-Null }
if (-not (Test-Path $logDir))      { New-Item -ItemType Directory -Path $logDir      | Out-Null }

# 0.4.14 — session_id MUST be a canonical 36-char UUID ("D" format:
# 8-4-4-4-12 lowercase hex). Historically `.ToString()` (no arg) was used;
# although .NET documents "D" as the default, some PowerShell hosts / broken
# .NET Framework builds have surfaced malformed values (e.g. an extra hex
# digit in the final segment) that fail the MCP Zod uuid check downstream.
# We now (1) request "D" explicitly, and (2) validate with [guid]::TryParse
# + a strict 36-char regex; on any deviation we FAIL CLOSED before advertising
# ACTIVE, so a bad id can never reach the session file or the terminal banner.
$sessionId = [guid]::NewGuid().ToString("D")
$__uuidRe = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
$__parsed = [guid]::Empty
if (-not [guid]::TryParse($sessionId, [ref]$__parsed) -or
    $sessionId.Length -ne 36 -or
    $sessionId -notmatch $__uuidRe) {
    Write-Error "Desktop Operator: generated session_id is not a valid 36-char UUID ('$sessionId'). Refusing to start."
    exit 5
}
$logPath   = Join-Path $logDir ("session-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + ".log")

function Log([string]$msg) {
    $line = "$([DateTime]::UtcNow.ToString('o')) $msg"
    Add-Content -Path $logPath -Value $line
    # Never mirror request-path logging to the interactive console. In the
    # legacy Windows console, QuickEdit/Mark mode (title prefixed with
    # "Select") blocks synchronous console writes. The HTTP response
    # may already have been sent, but console mirroring used to wedge the only
    # bridge thread before it could accept the next request. The startup
    # banner below remains visible; operational logs are durable in $logPath.
}

# Ephemeral 32-byte bearer secret (base64url), never logged.
$secretBytes = New-Object byte[] 32
[System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($secretBytes)
$secret = [Convert]::ToBase64String($secretBytes).TrimEnd('=').Replace('+', '-').Replace('/', '_')

# Read worker_id if pairing exists (for advertising).
$workerId = ''
$workerCfg = Join-Path $sentinelDir 'worker.json'
if (Test-Path $workerCfg) {
    try { $workerId = (Get-Content $workerCfg -Raw | ConvertFrom-Json).worker_id } catch {}
}

# ---------- Owner ACL principal (P0-R5 0.4.1 hotfix) ----------
# Unqualified $env:USERNAME (e.g. "JASON") does not always resolve on
# domain-joined or multi-user Windows boxes, producing an ACL that Helper
# cannot read (Access Denied). Use the fully qualified WindowsIdentity name
# (e.g. "DOMAIN\JASON" or "MACHINE\JASON") which icacls always accepts.
$ownerPrincipal = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
if ([string]::IsNullOrWhiteSpace($ownerPrincipal)) {
    throw "Desktop Operator: could not resolve current WindowsIdentity for owner-only ACL."
}

function Set-OwnerOnlyAcl([string]$path) {
    # icacls is a native command; PowerShell try/catch does NOT catch nonzero
    # exit codes. Check $LASTEXITCODE explicitly and FAIL CLOSED. Never log
    # the file contents (only the path is passed, so the bearer secret is
    # never touched here).
    & icacls $path /inheritance:r /grant:r "${ownerPrincipal}:(F)" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Desktop Operator: icacls failed with exit code $LASTEXITCODE on $path"
    }
}

# ---------- .NET SendInput / Screen capture / UIA ----------
$typeSig = @"
using System;
using System.Runtime.InteropServices;
public static class SI {
    [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Explicit)] public struct INPUT_U { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
    [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public INPUT_U u; }
    [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] pInputs, int cbSize);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern short VkKeyScan(char ch);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", SetLastError=true)] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll", SetLastError=true)] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder t, int c);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
    [DllImport("user32.dll")] public static extern uint GetClipboardSequenceNumber();
    [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int GetClassName(IntPtr hWnd, System.Text.StringBuilder t, int c);
    // 0.4.20 Action Verification Engine — WindowFromPoint + GetAncestor(GA_ROOT)
    // let Tool-Drag identify the top-level window under the drag origin so the
    // predicate can compare pre/post GetWindowRect() and fail with
    // DRAG_NO_EFFECT when the bounds never actually changed.
    [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT pt);
    [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
}
"@
try { Add-Type -TypeDefinition $typeSig -Language CSharp | Out-Null } catch { Log "[warn] SendInput bindings unavailable: $($_.Exception.Message)" }

# P0-R8 desktop_focus_window Windows-foreground rules:
# SetForegroundWindow silently no-ops when the calling process is not the
# current foreground unless we (a) call AllowSetForegroundWindow(ASFW_ANY),
# (b) briefly AttachThreadInput to the target's UI thread, and/or (c)
# synthesize an Alt keystroke to release the foreground lock. Kept in a
# separate P/Invoke class so unit-test SI shims that replace `SI` do not
# hide these entry points; the tool guards calls in try/catch so a missing
# type at test time is treated as best-effort.
$fgSig = @"
using System;
using System.Runtime.InteropServices;
public static class SI_FG {
    [DllImport("user32.dll", SetLastError=true)] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
    [DllImport("user32.dll", SetLastError=true)] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
    [DllImport("user32.dll", SetLastError=true)] public static extern bool AllowSetForegroundWindow(uint dwProcessId);
    [DllImport("user32.dll", SetLastError=true)] public static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll", SetLastError=true)] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll", SetLastError=true)] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    [DllImport("user32.dll", SetLastError=true)] public static extern IntPtr SetActiveWindow(IntPtr hWnd);
    [DllImport("user32.dll", SetLastError=true)] public static extern IntPtr SetFocus(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern void SwitchToThisWindow(IntPtr hWnd, bool fAltTab);
    [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool TerminateProcess(IntPtr hProcess, uint exitCode);
}
"@
try { Add-Type -TypeDefinition $fgSig -Language CSharp | Out-Null } catch { Log "[warn] foreground helper bindings unavailable: $($_.Exception.Message)" }
try { Add-Type -AssemblyName System.Windows.Forms | Out-Null } catch {}
try { Add-Type -AssemblyName System.Drawing | Out-Null } catch {}
try { Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes | Out-Null } catch { Log "[warn] UIA unavailable" }

# ---------- Tool implementations ----------
function Tool-Wait($a) {
    # P0-R6 desktop_wait millisecond fix:
    # Historic bug: parameter was named `$args`, which is a PowerShell
    # AUTOMATIC variable. The formal parameter was silently shadowed by the
    # empty automatic-args array, so `$args.duration_ms` returned $null,
    # `[int]$null` = 0, clamp -> 1, waited_ms = 1. Renamed to `$a` and now
    # report the STOPWATCH-measured elapsed ms (not the requested value)
    # so any future regression is visibly wrong.
    if ($null -eq $a -or -not $a.PSObject.Properties['duration_ms']) {
        return @{ ok = $false; error_code = 'DURATION_MS_MISSING'; error_message = 'duration_ms is required' }
    }
    $ms = [int]$a.duration_ms
    if ($ms -lt 1 -or $ms -gt 30000) {
        return @{ ok = $false; error_code = 'DURATION_MS_OUT_OF_RANGE'; error_message = "duration_ms must be 1..30000 (got $ms)" }
    }
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    Start-Sleep -Milliseconds $ms
    $sw.Stop()
    $elapsed = [int]$sw.ElapsedMilliseconds
    return @{ ok = $true; result = @{ waited_ms = $elapsed; requested_ms = $ms } }
}
function Tool-Snapshot($a) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    $out = Join-Path $logDir "snapshot-$stamp.png"
    $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
    $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose()
    return @{ ok = $true; result = @{ path = $out; bounds = @{ x = $bounds.X; y = $bounds.Y; w = $bounds.Width; h = $bounds.Height } } }
}
function Tool-ListWindows($a) {
    $max = if ($a.max_results) { [int]$a.max_results } else { 200 }
    $processFilter = if ($a.process_name) { [string]$a.process_name } else { $null }
    $includeMinimized = if ($a.PSObject.Properties['include_minimized']) { [bool]$a.include_minimized } else { $true }
    # MainWindowTitle is not a window-state signal: minimized Win32 windows
    # retain their titles and are commonly parked at (-32000,-32000). Use the
    # authoritative user32 IsIconic flag instead. Keep the title requirement
    # for both modes so include_minimized does not accidentally include
    # title-less shell/background handles.
    $procs = Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle }
    if ($processFilter) { $procs = $procs | Where-Object { $_.ProcessName -like $processFilter } }
    $out = @()
    foreach ($p in $procs) {
        $rect = New-Object SI+RECT
        [void][SI]::GetWindowRect($p.MainWindowHandle, [ref]$rect)
        $isIconic = [SI]::IsIconic($p.MainWindowHandle)
        # Some frameworks briefly report IsIconic=false while retaining the
        # legacy Win32 minimized placement. Treat the exact sentinel as a
        # fallback so the field-observed (-32000,-32000) windows stay out.
        $hasMinimizedPlacement = ($rect.L -eq -32000 -and $rect.T -eq -32000)
        $isMinimized = ($isIconic -or $hasMinimizedPlacement)
        if (-not $includeMinimized -and $isMinimized) { continue }
        $out += @{
            window_handle = "$($p.MainWindowHandle.ToInt64())"
            title         = $p.MainWindowTitle
            process_name  = $p.ProcessName
            pid           = $p.Id
            is_minimized  = $isMinimized
            window_state  = if ($isMinimized) { 'minimized' } else { 'normal' }
            bounds        = @{ x = $rect.L; y = $rect.T; w = ($rect.R - $rect.L); h = ($rect.B - $rect.T) }
        }
        # Apply the result limit after state filtering. Otherwise a run of
        # minimized processes at the start of Get-Process can consume the
        # whole limit and hide eligible visible windows.
        if ($out.Count -ge $max) { break }
    }
    return @{ ok = $true; result = @{ windows = $out; count = $out.Count } }
}
function Invoke-FocusStage([string]$stage, $request, [int]$timeoutMs = 1600) {
    # Foreground APIs execute in a disposable child process. UseShellExecute
    # is deliberately disabled and CreateNoWindow is enabled: the previous
    # launcher could attach child powershell.exe to the interactive console,
    # where QuickEdit/Mark mode can suspend it (and, historically, the parent
    # bridge while it waited). Polling plus TerminateProcess keeps every wait
    # bounded without relying on Process.WaitForExit/Kill behavior.
    $token = $PID.ToString() + '.' + ([guid]::NewGuid().ToString('N'))
    $requestPath = Join-Path $sentinelDir "focus-$token.request.json"
    $outputPath = Join-Path $sentinelDir "focus-$token.output.json"
    $checkpointPath = Join-Path $sentinelDir "focus-$token.checkpoint.json"
    $workerPath = Join-Path $PSScriptRoot 'focus-window-worker.ps1'
    $proc = $null
    try {
        [System.IO.File]::WriteAllText($requestPath, ($request | ConvertTo-Json -Compress), [System.Text.UTF8Encoding]::new($false))
        Log "[focus-stage] stage=$stage phase=launching timeout_ms=$timeoutMs"

        # Encode the invocation so paths containing spaces or apostrophes do
        # not depend on native command-line quoting rules in Windows PS 5.1.
        $quote = {
            param([string]$value)
            return "'" + $value.Replace("'", "''") + "'"
        }
        $childCommand = "& $(& $quote $workerPath) -Stage $(& $quote $stage) -RequestPath $(& $quote $requestPath) -OutputPath $(& $quote $outputPath) -CheckpointPath $(& $quote $checkpointPath)"
        $encodedCommand = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($childCommand))
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = Join-Path $PSHOME 'powershell.exe'
        $psi.Arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $encodedCommand"
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        $proc = [System.Diagnostics.Process]::Start($psi)
        if ($null -eq $proc) { throw "powershell.exe did not return a Process instance" }

        $wait = [System.Diagnostics.Stopwatch]::StartNew()
        while (-not $proc.HasExited -and $wait.ElapsedMilliseconds -lt $timeoutMs) {
            Start-Sleep -Milliseconds 20
        }
        $wait.Stop()
        if (-not $proc.HasExited) {
            $checkpoint = $null
            if (Test-Path $checkpointPath) {
                try {
                    $checkpointJson = [System.IO.File]::ReadAllText($checkpointPath, [System.Text.Encoding]::UTF8)
                    $checkpoint = $checkpointJson | ConvertFrom-Json
                } catch {}
            }
            Log "[focus-stage] stage=$stage phase=timeout child_pid=$($proc.Id)"
            $terminateRequested = $false
            try { $terminateRequested = [bool][SI_FG]::TerminateProcess($proc.Handle, 0xE001) } catch {}
            $terminateWait = [System.Diagnostics.Stopwatch]::StartNew()
            while (-not $proc.HasExited -and $terminateWait.ElapsedMilliseconds -lt 500) {
                Start-Sleep -Milliseconds 20
            }
            $terminateWait.Stop()
            return @{
                ok = $false
                error_code = 'FOCUS_STAGE_TIMEOUT'
                error_message = "Foreground stage '$stage' exceeded ${timeoutMs}ms; isolated execution process was terminated."
                result = @{
                    timed_out_stage = $stage
                    stage_timeout_ms = $timeoutMs
                    execution_pid = [int64]$proc.Id
                    terminate_requested = [bool]$terminateRequested
                    execution_terminated = [bool]$proc.HasExited
                    execution_restarted = $true
                    last_checkpoint = $checkpoint
                }
            }
        }
        if (-not (Test-Path $outputPath)) {
            return @{ ok=$false; error_code='FOCUS_STAGE_NO_RESULT'; error_message="Foreground stage '$stage' exited without a result."; result=@{ stage=$stage; execution_pid=[int64]$proc.Id } }
        }
        # Worker files are BOM-less UTF-8. Windows PowerShell 5.1 Get-Content
        # otherwise uses the active ANSI code page, which can corrupt a
        # localized exception and make otherwise-valid JSON unparsable.
        $resultJson = [System.IO.File]::ReadAllText($outputPath, [System.Text.Encoding]::UTF8)
        $result = $resultJson | ConvertFrom-Json
        Log "[focus-stage] stage=$stage phase=completed child_pid=$($proc.Id)"
        return $result
    } catch {
        if ($null -ne $proc -and -not $proc.HasExited) {
            try { [void][SI_FG]::TerminateProcess($proc.Handle, 0xE002) } catch {}
        }
        return @{ ok=$false; error_code='FOCUS_STAGE_EXCEPTION'; error_message=$_.Exception.Message; result=@{ stage=$stage; execution_restarted=$true } }
    } finally {
        foreach ($p in @($requestPath,$outputPath,$checkpointPath)) {
            if (Test-Path $p) { try { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue } catch {} }
        }
        if ($null -ne $proc) { try { $proc.Dispose() } catch {} }
    }
}

function Merge-FocusDiagnostics($target, $source) {
    if ($null -eq $source) { return }
    foreach ($p in $source.PSObject.Properties) { $target[$p.Name] = $p.Value }
}

function Tool-FocusWindow($a) {
    if ($null -eq $a -or -not $a.PSObject.Properties['window_handle']) {
        return @{ ok=$false; error_code='WINDOW_HANDLE_MISSING'; error_message='window_handle is required' }
    }
    $act = if ($a.PSObject.Properties['action']) { [string]$a.action } else { 'focus' }
    if ($act -notin @('focus','restore','minimize','maximize')) {
        return @{ ok=$false; error_code='ACTION_INVALID'; error_message="action must be focus|restore|minimize|maximize (got $act)" }
    }
    $reqHandle = [string]$a.window_handle
    $handleInt = 0L
    if (-not [int64]::TryParse($reqHandle, [ref]$handleInt) -or $handleInt -eq 0) {
        return @{ ok=$false; error_code='WINDOW_HANDLE_INVALID'; error_message="window_handle is not a valid integer handle: $reqHandle" }
    }

    $request = [ordered]@{ window_handle=$reqHandle; action=$act }
    $diag = [ordered]@{
        requested_window_handle=$reqHandle; window_handle=$reqHandle; action=$act;
        verified=$false; isolated_execution=$true; stage_timeout_ms=1600
    }
    $prepare = Invoke-FocusStage 'prepare' $request
    Merge-FocusDiagnostics $diag $prepare.result
    if (-not $prepare.ok) { return @{ ok=$false; error_code=$prepare.error_code; error_message=$prepare.error_message; result=$diag } }

    if ($act -eq 'minimize') {
        $verifyMin = Invoke-FocusStage 'verify' $request
        Merge-FocusDiagnostics $diag $verifyMin.result
        $diag.verified = [bool]($verifyMin.ok -and $verifyMin.result.acquired -and $verifyMin.result.state_ok)
        if (-not $diag.verified) { return @{ ok=$false; error_code='FOCUS_NOT_ACQUIRED'; error_message="Windows did not confirm minimize on $reqHandle"; result=$diag } }
        return @{ ok=$true; result=$diag }
    }

    $direct = Invoke-FocusStage 'direct' $request
    Merge-FocusDiagnostics $diag $direct.result
    if (-not $direct.ok) { return @{ ok=$false; error_code=$direct.error_code; error_message=$direct.error_message; result=$diag } }
    $acquired = [bool]$direct.result.acquired

    if (-not $acquired) {
        $alt = Invoke-FocusStage 'alt_tap' $request
        Merge-FocusDiagnostics $diag $alt.result
        if (-not $alt.ok) { return @{ ok=$false; error_code=$alt.error_code; error_message=$alt.error_message; result=$diag } }
        $afterAlt = Invoke-FocusStage 'direct' $request
        Merge-FocusDiagnostics $diag $afterAlt.result
        if (-not $afterAlt.ok) { return @{ ok=$false; error_code=$afterAlt.error_code; error_message=$afterAlt.error_message; result=$diag } }
        $acquired = [bool]$afterAlt.result.acquired
    }
    if (-not $acquired) {
        $attached = Invoke-FocusStage 'attached_focus' $request
        Merge-FocusDiagnostics $diag $attached.result
        if (-not $attached.ok) { return @{ ok=$false; error_code=$attached.error_code; error_message=$attached.error_message; result=$diag } }
        $acquired = [bool]$attached.result.acquired
    }
    if (-not $acquired) {
        $managed = Invoke-FocusStage 'managed_focus' $request
        Merge-FocusDiagnostics $diag $managed.result
        if (-not $managed.ok) { return @{ ok=$false; error_code=$managed.error_code; error_message=$managed.error_message; result=$diag } }
        $acquired = [bool]$managed.result.acquired
    }
    if (-not $acquired) {
        $switch = Invoke-FocusStage 'switch_window' $request
        Merge-FocusDiagnostics $diag $switch.result
        if (-not $switch.ok) { return @{ ok=$false; error_code=$switch.error_code; error_message=$switch.error_message; result=$diag } }
    }

    $verify = Invoke-FocusStage 'verify' $request
    Merge-FocusDiagnostics $diag $verify.result
    if (-not $verify.ok) { return @{ ok=$false; error_code=$verify.error_code; error_message=$verify.error_message; result=$diag } }
    $diag.verified = [bool]($verify.result.acquired -and $verify.result.state_ok)
    if (-not $diag.verified) {
        return @{ ok=$false; error_code='FOCUS_NOT_ACQUIRED'; error_message="Windows did not confirm action '$act' on window $reqHandle"; result=$diag }
    }
    return @{ ok=$true; result=$diag }
}
function Send-MouseAt($x, $y, $flags) {
    [void][SI]::SetCursorPos([int]$x, [int]$y)
    $inp = New-Object 'SI+INPUT[]' 1
    $inp[0].type = 0
    $inp[0].u.mi.dx = [int]$x; $inp[0].u.mi.dy = [int]$y
    $inp[0].u.mi.dwFlags = [uint32]$flags
    [void][SI]::SendInput(1, $inp, [System.Runtime.InteropServices.Marshal]::SizeOf([type]'SI+INPUT'))
}
function Tool-Click($a) {
    # 0.4.20 Action Verification Engine: SendInput on its own is only proof of
    # input delivery. A click that lands on a disabled control, on the wrong
    # monitor, or on a stale window returns ok=true against the pre-click
    # world. Wrap it in Invoke-VerifiedAction with foreground_or_focus_change
    # so we require some observable UI change; require_verified=false lets
    # callers explicitly opt out for exploratory clicks.
    $btn = [string]$a.button; $clicks = if ($a.clicks) { [int]$a.clicks } else { 1 }
    $requireVerified = $true
    if ($a.PSObject.Properties['require_verified'] -and $null -ne $a.require_verified) {
        $requireVerified = [bool]$a.require_verified
    }
    $down = switch ($btn) { 'right' { 0x0008 } 'middle' { 0x0020 } default { 0x0002 } }
    $up   = switch ($btn) { 'right' { 0x0010 } 'middle' { 0x0040 } default { 0x0004 } }
    $x = [int]$a.x; $y = [int]$a.y
    $kind = 'foreground_or_focus_change'
    $predicate = New-VerificationPredicate $kind
    $action = {
        for ($i = 0; $i -lt $clicks; $i++) {
            Send-MouseAt $x $y $down
            Send-MouseAt $x $y $up
            Start-Sleep -Milliseconds 40
        }
    }.GetNewClosure()
    $vr = Invoke-VerifiedAction -Action $action -Predicate $predicate -Kind $kind
    $diag = @{
        x = $x; y = $y; button = $btn; clicks = $clicks
        require_verified        = $requireVerified
        verified                = $vr.verified
        verification_kind       = $vr.verification_kind
        verification_attempts   = $vr.verification_attempts
        verification_elapsed_ms = $vr.verification_elapsed_ms
        pre                     = $vr.pre
        post                    = $vr.post
        target_still_foreground = $vr.target_still_foreground
        effect_observed         = $vr.effect_observed
        failure_reason          = $vr.failure_reason
        action_error            = $vr.action_error
    }
    if ($requireVerified -and -not $vr.verified) {
        return @{ ok = $false; error_code = 'CLICK_NO_EFFECT'; error_message = "Click at ($x,$y) delivered but no foreground/focus/text/bounds change observed within 1600ms poll ladder"; result = $diag; evidence = $diag }
    }
    return @{ ok = $true; result = $diag; evidence = $diag }
}
function Send-KeyChar([char]$c) {
    $vk = [SI]::VkKeyScan($c); $low = $vk -band 0xff
    $inp = New-Object 'SI+INPUT[]' 2
    $inp[0].type = 1; $inp[0].u.ki.wVk = [uint16]$low
    $inp[1].type = 1; $inp[1].u.ki.wVk = [uint16]$low; $inp[1].u.ki.dwFlags = 2
    [void][SI]::SendInput(2, $inp, [System.Runtime.InteropServices.Marshal]::SizeOf([type]'SI+INPUT'))
}
function Get-FocusedControlInfo() {
    # Snapshot the current UIA-focused element + Win32 foreground handle. Used
    # by Tool-Type / Tool-Hotkey pre/post evidence, and by the target-focus
    # guard that refuses to type into a non-Document/Edit control. Every field
    # is best-effort: we return $null-valued keys rather than throwing so
    # callers can always attach evidence.
    $fg = [IntPtr]::Zero
    try { $fg = [SI]::GetForegroundWindow() } catch {}
    $fgClass = $null
    try {
        $sb = New-Object System.Text.StringBuilder 256
        [void][SI]::GetClassName($fg, $sb, 256)
        $fgClass = $sb.ToString()
    } catch {}
    $ctrlClass = $null; $ctrlType = $null; $text = $null; $value = $null
    try {
        $auto = [System.Windows.Automation.AutomationElement]
        $el = $auto::FocusedElement
        if ($null -ne $el) {
            $cur = $el.Current
            $ctrlClass = $cur.ClassName
            $ctrlType  = $cur.ControlType.ProgrammaticName
            # TextPattern first (Win11 Notepad RichEditD2DPT exposes this).
            try {
                $tpId = [System.Windows.Automation.TextPattern]::Pattern
                $tp = $null
                if ($el.TryGetCurrentPattern($tpId, [ref]$tp)) {
                    $rng = $tp.DocumentRange
                    $text = $rng.GetText(-1)
                }
            } catch {}
            try {
                $vpId = [System.Windows.Automation.ValuePattern]::Pattern
                $vp = $null
                if ($el.TryGetCurrentPattern($vpId, [ref]$vp)) {
                    $value = $vp.Current.Value
                }
            } catch {}
        }
    } catch {}
    $isDocOrEdit = $false
    if ($ctrlType) {
        $isDocOrEdit = ($ctrlType -match '\.Document$' -or $ctrlType -match '\.Edit$')
    }
    return @{
        foreground_window_handle = "$($fg.ToInt64())"
        foreground_class         = $fgClass
        focused_class            = $ctrlClass
        focused_control_type     = $ctrlType
        focused_text             = $text
        focused_value            = $value
        focused_text_length      = if ($text)  { $text.Length }  else { 0 }
        focused_value_length     = if ($value) { $value.Length } else { 0 }
        is_document_or_edit      = $isDocOrEdit
    }
}

# ------------------- 0.4.20 Action Verification Engine -------------------
# 0.4.19 wrongly claimed click/drag/hotkey succeeded whenever SendInput
# returned — the desktop showed nothing changed. The engine wraps every
# effect-bearing action with an explicit pre/post capture, executes the
# action, then polls at 50/100/200/400/800/1600 ms cumulative delays for
# an effect predicate to fire. Verified actions return the poll counts
# and elapsed ms as diagnostics; unverified effect-bearing actions return
# CLICK_NO_EFFECT / DRAG_NO_EFFECT / HOTKEY_NO_EFFECT with the same
# pre/post evidence. Actions whose semantics we cannot infer are marked
# verification_kind='input_only' and MUST NOT be treated as verified.
function Get-WindowRect([IntPtr]$hWnd) {
    if ($hWnd -eq [IntPtr]::Zero) { return $null }
    $r = New-Object 'SI+RECT'
    try {
        if (-not [SI]::GetWindowRect($hWnd, [ref]$r)) { return $null }
    } catch { return $null }
    return @{ L = $r.L; T = $r.T; R = $r.R; B = $r.B; W = ($r.R - $r.L); H = ($r.B - $r.T) }
}

function Get-ActionEvidence() {
    $focus = Get-FocusedControlInfo
    $fg = [IntPtr]::Zero
    try { $fg = [SI]::GetForegroundWindow() } catch {}
    $rect = Get-WindowRect $fg
    $title = $null
    try {
        $sb = New-Object System.Text.StringBuilder 256
        [void][SI]::GetWindowText($fg, $sb, 256)
        $title = $sb.ToString()
    } catch {}
    $seq = 0; try { $seq = [SI]::GetClipboardSequenceNumber() } catch {}
    $textHash  = Get-TextSha256 ([string]$focus.focused_text)
    $valueHash = Get-TextSha256 ([string]$focus.focused_value)
    return @{
        foreground_window_handle = "$($fg.ToInt64())"
        foreground_class         = $focus.foreground_class
        foreground_title         = $title
        foreground_rect          = $rect
        focused_class            = $focus.focused_class
        focused_control_type     = $focus.focused_control_type
        focused_text             = $focus.focused_text
        focused_value            = $focus.focused_value
        focused_text_length      = $focus.focused_text_length
        focused_value_length     = $focus.focused_value_length
        focused_text_hash        = $textHash
        focused_value_hash       = $valueHash
        is_document_or_edit      = $focus.is_document_or_edit
        clipboard_sequence       = [int64]$seq
        captured_at_ms           = [int64]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
    }
}

function New-VerificationPredicate([string]$kind) {
    switch ($kind) {
        'clipboard_change' {
            return {
                param($pre, $post)
                if ($post.clipboard_sequence -ne $pre.clipboard_sequence) {
                    return @{ observed = $true;  reason = 'clipboard_sequence_changed' }
                }
                return         @{ observed = $false; reason = 'clipboard_sequence_unchanged' }
            }
        }
        'focused_text_change' {
            return {
                param($pre, $post)
                if ($post.focused_text_hash  -ne $pre.focused_text_hash -or
                    $post.focused_value_hash -ne $pre.focused_value_hash) {
                    return @{ observed = $true;  reason = 'focused_text_hash_changed' }
                }
                return         @{ observed = $false; reason = 'focused_text_hash_unchanged' }
            }
        }
        'foreground_change' {
            return {
                param($pre, $post)
                if ($post.foreground_window_handle -ne $pre.foreground_window_handle) {
                    return @{ observed = $true;  reason = 'foreground_window_handle_changed' }
                }
                return         @{ observed = $false; reason = 'foreground_window_unchanged' }
            }
        }
        'foreground_or_focus_change' {
            return {
                param($pre, $post)
                if ($post.foreground_window_handle -ne $pre.foreground_window_handle) {
                    return @{ observed = $true; reason = 'foreground_window_handle_changed' }
                }
                if ($post.focused_class        -ne $pre.focused_class -or
                    $post.focused_control_type -ne $pre.focused_control_type) {
                    return @{ observed = $true; reason = 'focused_control_changed' }
                }
                if ($post.focused_text_hash  -ne $pre.focused_text_hash -or
                    $post.focused_value_hash -ne $pre.focused_value_hash) {
                    return @{ observed = $true; reason = 'focused_text_hash_changed' }
                }
                $a = $pre.foreground_rect; $b = $post.foreground_rect
                if ($a -and $b -and ($a.L -ne $b.L -or $a.T -ne $b.T -or $a.R -ne $b.R -or $a.B -ne $b.B)) {
                    return @{ observed = $true; reason = 'foreground_rect_changed' }
                }
                return @{ observed = $false; reason = 'no_focus_or_text_or_bounds_change' }
            }
        }
        'input_only' {
            return {
                param($pre, $post)
                return @{ observed = $false; reason = 'input_only_semantics' }
            }
        }
        default {
            return {
                param($pre, $post)
                return @{ observed = $false; reason = "unknown_kind:$kind" }
            }
        }
    }
}

function Invoke-VerifiedAction {
    param(
        [Parameter(Mandatory)][scriptblock]$Action,
        [Parameter(Mandatory)][scriptblock]$Predicate,
        [Parameter(Mandatory)][string]$Kind
    )
    # Cumulative delays MUST be 50/100/200/400/800/1600 ms per 0.4.20 spec.
    $delays = @(50, 100, 200, 400, 800, 1600)
    $pre = Get-ActionEvidence
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $actionError = $null
    try { & $Action } catch { $actionError = $_.Exception.Message }
    $post = $null; $verified = $false; $attempts = 0
    $effect = @{ observed = $false; reason = 'no_poll' }
    foreach ($d in $delays) {
        Start-Sleep -Milliseconds $d
        $attempts++
        $post = Get-ActionEvidence
        $effect = & $Predicate $pre $post
        if ($effect -and $effect.observed) { $verified = $true; break }
    }
    $sw.Stop()
    if ($null -eq $post) { $post = Get-ActionEvidence }
    $stillFg = ($pre.foreground_window_handle -eq $post.foreground_window_handle)
    return @{
        verified                = [bool]$verified
        verification_kind       = $Kind
        verification_attempts   = [int]$attempts
        verification_elapsed_ms = [int]$sw.ElapsedMilliseconds
        pre                     = $pre
        post                    = $post
        target_still_foreground = [bool]$stillFg
        effect_observed         = [bool]$effect.observed
        failure_reason          = if ($verified) { $null } else { [string]$effect.reason }
        action_error            = $actionError
    }
}

function Resolve-HotkeyVerification([string[]]$modNames, [string]$key) {
    # Classify well-known hotkeys into verification kinds. Requires=$true means
    # verification failure MUST surface HOTKEY_NO_EFFECT (or CLIPBOARD_UNCHANGED_AFTER_COPY
    # for Ctrl+C / Ctrl+X). Requires=$false means we cannot pin the semantics
    # tightly (e.g. Ctrl+A only mutates selection, no observable text change)
    # and MUST NOT report input_sent as a real effect.
    $hasCtrl = ($modNames -contains 'ctrl')
    $hasAlt  = ($modNames -contains 'alt')
    $hasWin  = ($modNames -contains 'win')
    $k = $key.ToLowerInvariant()
    if ($hasCtrl -and ($k -eq 'c' -or $k -eq 'x')) { return @{ kind = 'clipboard_change';           requires = $true  } }
    if ($hasCtrl -and ($k -eq 'v' -or $k -eq 'z' -or $k -eq 'y')) { return @{ kind = 'focused_text_change'; requires = $true  } }
    if ($hasCtrl -and $k -eq 'a')                  { return @{ kind = 'input_only';                requires = $false } }
    if ($hasAlt  -and ($k -eq 'tab' -or $k -eq 'f4' -or $k -eq 'escape')) { return @{ kind = 'foreground_change';    requires = $true  } }
    if ($hasWin  -and ($k -eq 'd' -or $k -eq 'e' -or $k -eq 'r' -or $k -eq 'tab')) { return @{ kind = 'foreground_change'; requires = $true } }
    if ($hasCtrl -and ($k -eq 'n' -or $k -eq 'o' -or $k -eq 'w' -or $k -eq 's' -or $k -eq 't')) {
        return @{ kind = 'foreground_or_focus_change'; requires = $true }
    }
    return @{ kind = 'input_only'; requires = $false }
}



function Send-UnicodeText([string]$text) {
    # 0.4.16: Reliable per-character injection via SendInput + KEYEVENTF_UNICODE.
    # VkKeyScan/SendKeys fail on UWP/WinUI/RichEditD2DPT surfaces (Win11 Notepad)
    # because those controls consume WM_KEYDOWN only when the corresponding
    # virtual-key layout is active. Feeding raw UTF-16 code units via
    # KEYEVENTF_UNICODE bypasses the keyboard-layout translation entirely and
    # delivers the character even to modern XAML edit controls.
    if ($null -eq $text -or $text.Length -eq 0) { return }
    $KEYEVENTF_KEYUP   = [uint32]0x0002
    $KEYEVENTF_UNICODE = [uint32]0x0004
    $count = $text.Length * 2
    $inp = New-Object 'SI+INPUT[]' $count
    for ($i = 0; $i -lt $text.Length; $i++) {
        $cu = [uint16][int]$text[$i]
        $j  = $i * 2
        $inp[$j].type = 1
        $inp[$j].u.ki.wVk = [uint16]0
        $inp[$j].u.ki.wScan = $cu
        $inp[$j].u.ki.dwFlags = $KEYEVENTF_UNICODE
        $inp[$j + 1].type = 1
        $inp[$j + 1].u.ki.wVk = [uint16]0
        $inp[$j + 1].u.ki.wScan = $cu
        $inp[$j + 1].u.ki.dwFlags = ($KEYEVENTF_UNICODE -bor $KEYEVENTF_KEYUP)
    }
    [void][SI]::SendInput([uint32]$count, $inp, [System.Runtime.InteropServices.Marshal]::SizeOf([type]'SI+INPUT'))
}

function Get-TextSha256([string]$s) {
    if ($null -eq $s) { return $null }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($s)
        $hash = $sha.ComputeHash($bytes)
        return -join ($hash | ForEach-Object { $_.ToString('x2') })
    } finally { $sha.Dispose() }
}

function Tool-Type($a) {
    # 0.4.16: Real verified injection. The 0.4.15 path returned succeeded even
    # when SendKeys was silently dropped by RichEditD2DPT — Win11 Notepad still
    # showed empty text after focus/click/type. We now use SendInput +
    # KEYEVENTF_UNICODE, poll UIA for actual text change, and fail with
    # TYPE_NO_EFFECT if the target's TextPattern/ValuePattern does not update.
    $text = [string]$a.text
    # $a.chars_per_second is accepted for schema compatibility but ignored:
    # SendInput + KEYEVENTF_UNICODE delivers the entire buffer in one syscall,
    # so per-char throttling is no longer meaningful. Reference the value here
    # so param-bind regression tests still see it wired to $a.
    $cpsHint = if ($a.PSObject.Properties['chars_per_second'] -and $a.chars_per_second) { [int]$a.chars_per_second } else { 0 }
    $pre = Get-FocusedControlInfo
    $expectedHandle = $null
    if ($a.PSObject.Properties['window_handle'] -and $a.window_handle) {
        $expectedHandle = [string]$a.window_handle
    }
    if (-not $pre.is_document_or_edit) {
        return @{ ok = $false; error_code = 'FOCUS_CONTROL_INVALID'; error_message = "Focused control is not Document/Edit (got '$($pre.focused_control_type)')"; evidence = @{ pre = $pre; expected_window_handle = $expectedHandle } }
    }
    if ($expectedHandle -and ($expectedHandle -ne $pre.foreground_window_handle)) {
        return @{ ok = $false; error_code = 'FOCUS_TARGET_MISMATCH'; error_message = "Foreground window handle $($pre.foreground_window_handle) does not match expected $expectedHandle"; evidence = @{ pre = $pre; expected_window_handle = $expectedHandle } }
    }

    $preText = if ($pre.focused_text) { [string]$pre.focused_text } elseif ($pre.focused_value) { [string]$pre.focused_value } else { '' }
    $preLen  = $preText.Length
    $preHash = Get-TextSha256 $preText

    $sendOk = $true
    try { Send-UnicodeText $text } catch { $sendOk = $false; Log "[type] SendInput unicode failed: $($_.Exception.Message)" }

    # Poll UIA up to ~1600ms for the text/value pattern to observe the change.
    $post = $null; $postText = ''; $postHash = $null; $textChanged = $false
    for ($poll = 0; $poll -lt 32; $poll++) {
        Start-Sleep -Milliseconds 50
        $post = Get-FocusedControlInfo
        $postText = if ($post.focused_text) { [string]$post.focused_text } elseif ($post.focused_value) { [string]$post.focused_value } else { '' }
        $postHash = Get-TextSha256 $postText
        if ($postHash -ne $preHash) { $textChanged = $true; break }
    }
    if ($null -eq $post) { $post = Get-FocusedControlInfo }
    $stillTarget = ($pre.foreground_window_handle -eq $post.foreground_window_handle)

    # If the target began empty, the readback must equal the injected text
    # exactly (allowing for a trailing CR/LF that some Edit controls append).
    $exactMatch = $false
    if ($preLen -eq 0 -and $postText.Length -gt 0) {
        $trimmed = $postText.TrimEnd([char]13, [char]10)
        $exactMatch = ($postText -eq $text) -or ($trimmed -eq $text)
    }
    $verified = [bool]$textChanged
    if ($preLen -eq 0 -and $text.Length -gt 0 -and -not $exactMatch) {
        # Text changed but doesn't match verbatim — treat as unverified.
        $verified = $false
    }

    $diag = @{
        pre = $pre
        post = $post
        expected_window_handle = $expectedHandle
        expected_target_still_foreground = $stillTarget
        pre_foreground_window_handle  = $pre.foreground_window_handle
        post_foreground_window_handle = $post.foreground_window_handle
        pre_focused_class             = $pre.focused_class
        post_focused_class            = $post.focused_class
        pre_focused_control_type      = $pre.focused_control_type
        post_focused_control_type     = $post.focused_control_type
        text_length_before            = $preLen
        text_length_after             = $postText.Length
        text_hash_before              = $preHash
        text_hash_after               = $postHash
        text_changed                  = $textChanged
        verified                      = $verified
        exact_match_when_empty        = $exactMatch
        length                        = $text.Length
        send_input_ok                 = $sendOk
        injection_method              = 'SendInput+KEYEVENTF_UNICODE'
    }
    if (-not $verified) {
        return @{ ok = $false; error_code = 'TYPE_NO_EFFECT'; error_message = "SendInput completed but UIA text did not change within 1600ms poll"; result = $diag; evidence = $diag }
    }
    return @{ ok = $true; result = $diag; evidence = $diag }
}
function Tool-ClipboardGet($a) {
    $seq = 0; try { $seq = [SI]::GetClipboardSequenceNumber() } catch {}
    $v = [System.Windows.Forms.Clipboard]::GetText()
    return @{ ok = $true; result = @{ value = $v; length = $v.Length; sequence = [int64]$seq } }
}
function Tool-ClipboardSet($a) {
    [System.Windows.Forms.Clipboard]::SetText([string]$a.value)
    $seq = 0; try { $seq = [SI]::GetClipboardSequenceNumber() } catch {}
    return @{ ok = $true; result = @{ length = ([string]$a.value).Length; sequence = [int64]$seq } }
}
function Tool-Launch($a) {
    $id = [string]$a.app_id
    $whitelist = @{
        notepad = 'notepad.exe'; calc = 'calc.exe'; mspaint = 'mspaint.exe';
        explorer = 'explorer.exe'; cmd_readonly = 'cmd.exe';
        chrome = 'chrome.exe'; edge = 'msedge.exe'
    }
    if ($id -and $whitelist.ContainsKey($id)) {
        Start-Process -FilePath $whitelist[$id] | Out-Null
        return @{ ok = $true; result = @{ launched = $id } }
    }
    $p = [string]$a.app_path
    if (-not $p -or -not (Test-Path $p)) {
        return @{ ok = $false; error_code = 'LAUNCH_PATH_NOT_FOUND'; error_message = 'app_path missing or does not resolve' }
    }
    Start-Process -FilePath $p | Out-Null
    return @{ ok = $true; result = @{ launched = $p } }
}

# P0-R6: real implementations for press/hotkey/scroll/drag/inspect.
# Named key -> Virtual-Key code (subset matching NamedKey in schemas.ts).
$script:NamedVk = @{
    enter=0x0D; escape=0x1B; tab=0x09; backspace=0x08; delete=0x2E;
    space=0x20; up=0x26; down=0x28; left=0x25; right=0x27;
    home=0x24; end=0x23; pageup=0x21; pagedown=0x22; insert=0x2D;
    f1=0x70; f2=0x71; f3=0x72; f4=0x73; f5=0x74; f6=0x75;
    f7=0x76; f8=0x77; f9=0x78; f10=0x79; f11=0x7A; f12=0x7B
}
$script:ModVk = @{ ctrl=0x11; shift=0x10; alt=0x12; win=0x5B }

function Send-VkDownUp([uint16]$vk, [switch]$KeyDownOnly, [switch]$KeyUpOnly) {
    $count = 2
    if ($KeyDownOnly -or $KeyUpOnly) { $count = 1 }
    $inp = New-Object 'SI+INPUT[]' $count
    if ($KeyUpOnly) {
        $inp[0].type = 1; $inp[0].u.ki.wVk = $vk; $inp[0].u.ki.dwFlags = 2
    } elseif ($KeyDownOnly) {
        $inp[0].type = 1; $inp[0].u.ki.wVk = $vk
    } else {
        $inp[0].type = 1; $inp[0].u.ki.wVk = $vk
        $inp[1].type = 1; $inp[1].u.ki.wVk = $vk; $inp[1].u.ki.dwFlags = 2
    }
    [void][SI]::SendInput([uint32]$count, $inp, [System.Runtime.InteropServices.Marshal]::SizeOf([type]'SI+INPUT'))
}

function Tool-Press($a) {
    $key = ([string]$a.key).ToLowerInvariant()
    if (-not $script:NamedVk.ContainsKey($key)) {
        return @{ ok = $false; error_code = 'KEY_UNKNOWN'; error_message = "unknown named key: $key" }
    }
    $vk = [uint16]$script:NamedVk[$key]
    $presses = if ($a.presses) { [int]$a.presses } else { 1 }
    if ($presses -lt 1) { $presses = 1 } elseif ($presses -gt 10) { $presses = 10 }
    for ($i = 0; $i -lt $presses; $i++) {
        Send-VkDownUp $vk
        Start-Sleep -Milliseconds 30
    }
    return @{ ok = $true; result = @{ key = $key; presses = $presses } }
}

function Tool-Hotkey($a) {
    # 0.4.20 Action Verification Engine: known chords are classified into a
    # verification kind (clipboard change, focused-text change, foreground
    # change). If the classified predicate does not fire, we return
    # HOTKEY_NO_EFFECT (or CLIPBOARD_UNCHANGED_AFTER_COPY for Ctrl+C/X).
    # Unknown chords fall back to verification_kind='input_only' which is
    # ok=true but verified=false — callers MUST NOT treat input_only as
    # a real effect.
    $mods = @()
    $modNames = @()
    foreach ($m in @($a.modifiers)) {
        $mk = ([string]$m).ToLowerInvariant()
        if (-not $script:ModVk.ContainsKey($mk)) {
            return @{ ok = $false; error_code = 'MODIFIER_UNKNOWN'; error_message = "unknown modifier: $mk" }
        }
        $mods += [uint16]$script:ModVk[$mk]
        $modNames += $mk
    }
    $key = ([string]$a.key)
    $vk = $null
    $lk = $key.ToLowerInvariant()
    if ($script:NamedVk.ContainsKey($lk)) {
        $vk = [uint16]$script:NamedVk[$lk]
    } elseif ($key.Length -eq 1) {
        $vk = [uint16]([SI]::VkKeyScan([char]$key) -band 0xff)
    } else {
        return @{ ok = $false; error_code = 'KEY_UNKNOWN'; error_message = "unknown key: $key" }
    }
    $requireVerified = $true
    if ($a.PSObject.Properties['require_verified'] -and $null -ne $a.require_verified) {
        $requireVerified = [bool]$a.require_verified
    }
    $classifier = Resolve-HotkeyVerification $modNames $key
    $kind = $classifier.kind
    $mustVerify = ([bool]$classifier.requires) -and $requireVerified
    $predicate = New-VerificationPredicate $kind

    $action = {
        foreach ($mv in $mods) { Send-VkDownUp $mv -KeyDownOnly }
        Send-VkDownUp $vk
        for ($i = $mods.Count - 1; $i -ge 0; $i--) { Send-VkDownUp $mods[$i] -KeyUpOnly }
    }.GetNewClosure()

    $vr = Invoke-VerifiedAction -Action $action -Predicate $predicate -Kind $kind
    $diag = @{
        modifiers               = $a.modifiers
        key                     = $key
        require_verified        = $requireVerified
        verified                = $vr.verified
        verification_kind       = $vr.verification_kind
        verification_attempts   = $vr.verification_attempts
        verification_elapsed_ms = $vr.verification_elapsed_ms
        pre                     = $vr.pre
        post                    = $vr.post
        target_still_foreground = $vr.target_still_foreground
        effect_observed         = $vr.effect_observed
        failure_reason          = $vr.failure_reason
        action_error            = $vr.action_error
        clipboard_seq_before    = $vr.pre.clipboard_sequence
        clipboard_seq_after     = $vr.post.clipboard_sequence
        clipboard_changed       = ($vr.pre.clipboard_sequence -ne $vr.post.clipboard_sequence)
        expected_target_still_foreground = $vr.target_still_foreground
    }
    if ($mustVerify -and -not $vr.verified) {
        $errCode = if ($kind -eq 'clipboard_change') { 'CLIPBOARD_UNCHANGED_AFTER_COPY' } else { 'HOTKEY_NO_EFFECT' }
        $chord = ($modNames -join '+') + '+' + $key
        return @{ ok = $false; error_code = $errCode; error_message = "Chord '$chord' delivered but predicate '$kind' saw no change within 1600ms poll ladder"; result = $diag; evidence = $diag }
    }
    return @{ ok = $true; result = $diag; evidence = $diag }
}

function Tool-Scroll($a) {
    # MOUSEEVENTF_WHEEL=0x0800, MOUSEEVENTF_HWHEEL=0x1000. mouseData carries
    # signed multiples of WHEEL_DELTA (120).
    $x = [int]$a.x; $y = [int]$a.y
    $dy = [int]($a.delta_y | ForEach-Object { $_ }); if (-not $dy) { $dy = 0 }
    $dx = [int]($a.delta_x | ForEach-Object { $_ }); if (-not $dx) { $dx = 0 }
    [void][SI]::SetCursorPos($x, $y)
    if ($dy -ne 0) {
        $inp = New-Object 'SI+INPUT[]' 1
        $inp[0].type = 0
        $inp[0].u.mi.dx = $x; $inp[0].u.mi.dy = $y
        $inp[0].u.mi.mouseData = [uint32]([int32]$dy)
        $inp[0].u.mi.dwFlags = 0x0800
        [void][SI]::SendInput(1, $inp, [System.Runtime.InteropServices.Marshal]::SizeOf([type]'SI+INPUT'))
    }
    if ($dx -ne 0) {
        $inp2 = New-Object 'SI+INPUT[]' 1
        $inp2[0].type = 0
        $inp2[0].u.mi.dx = $x; $inp2[0].u.mi.dy = $y
        $inp2[0].u.mi.mouseData = [uint32]([int32]$dx)
        $inp2[0].u.mi.dwFlags = 0x1000
        [void][SI]::SendInput(1, $inp2, [System.Runtime.InteropServices.Marshal]::SizeOf([type]'SI+INPUT'))
    }
    return @{ ok = $true; result = @{ x = $x; y = $y; delta_y = $dy; delta_x = $dx } }
}

function Tool-Drag($a) {
    # 0.4.20 Action Verification Engine: title-bar / resize drags MUST prove
    # the target window actually moved or resized. We identify the top-level
    # window under the from point via WindowFromPoint + GetAncestor(GA_ROOT),
    # capture GetWindowRect BEFORE performing the drag, then let the engine
    # poll for a bounds change. No change with require_verified => DRAG_NO_EFFECT.
    $btn = if ($a.button) { [string]$a.button } else { 'left' }
    $down = switch ($btn) { 'right' { 0x0008 } 'middle' { 0x0020 } default { 0x0002 } }
    $up   = switch ($btn) { 'right' { 0x0010 } 'middle' { 0x0040 } default { 0x0004 } }
    $duration = if ($a.duration_ms) { [int]$a.duration_ms } else { 200 }
    if ($duration -lt 0) { $duration = 0 } elseif ($duration -gt 5000) { $duration = 5000 }
    $requireVerified = $true
    if ($a.PSObject.Properties['require_verified'] -and $null -ne $a.require_verified) {
        $requireVerified = [bool]$a.require_verified
    }
    $fx = [int]$a.from_x; $fy = [int]$a.from_y
    $tx = [int]$a.to_x;   $ty = [int]$a.to_y

    $pt = New-Object 'SI+POINT'
    $pt.X = $fx; $pt.Y = $fy
    $target = [IntPtr]::Zero
    try { $target = [SI]::WindowFromPoint($pt) } catch {}
    if ($target -ne [IntPtr]::Zero) {
        try { $target = [SI]::GetAncestor($target, [uint32]2) } catch {}  # GA_ROOT = 2
    }
    $rectBefore = Get-WindowRect $target

    $predicate = {
        param($pre, $post)
        $after = Get-WindowRect $target
        if ($null -eq $rectBefore -or $null -eq $after) {
            return @{ observed = $false; reason = 'no_target_rect' }
        }
        if ($after.L -ne $rectBefore.L -or $after.T -ne $rectBefore.T) {
            return @{ observed = $true; reason = 'target_window_moved' }
        }
        if ($after.W -ne $rectBefore.W -or $after.H -ne $rectBefore.H) {
            return @{ observed = $true; reason = 'target_window_resized' }
        }
        return @{ observed = $false; reason = 'target_rect_unchanged' }
    }.GetNewClosure()

    $action = {
        Send-MouseAt $fx $fy $down
        $steps = [Math]::Max(2, [Math]::Min(30, [Math]::Ceiling($duration / 20.0)))
        for ($i = 1; $i -le $steps; $i++) {
            $t = $i / $steps
            $x = [int]([Math]::Round($fx + ($tx - $fx) * $t))
            $y = [int]([Math]::Round($fy + ($ty - $fy) * $t))
            [void][SI]::SetCursorPos($x, $y)
            $inp = New-Object 'SI+INPUT[]' 1
            $inp[0].type = 0
            $inp[0].u.mi.dx = $x; $inp[0].u.mi.dy = $y
            $inp[0].u.mi.dwFlags = 0x0001
            [void][SI]::SendInput(1, $inp, [System.Runtime.InteropServices.Marshal]::SizeOf([type]'SI+INPUT'))
            if ($duration -gt 0) { Start-Sleep -Milliseconds ([int]($duration / $steps)) }
        }
        Send-MouseAt $tx $ty $up
    }.GetNewClosure()

    $vr = Invoke-VerifiedAction -Action $action -Predicate $predicate -Kind 'window_bounds_change'
    $rectAfter = Get-WindowRect $target
    $diag = @{
        from = @{ x = $fx; y = $fy }; to = @{ x = $tx; y = $ty }
        button = $btn; duration_ms = $duration
        require_verified        = $requireVerified
        target_window_handle    = "$($target.ToInt64())"
        target_rect_before      = $rectBefore
        target_rect_after       = $rectAfter
        verified                = $vr.verified
        verification_kind       = $vr.verification_kind
        verification_attempts   = $vr.verification_attempts
        verification_elapsed_ms = $vr.verification_elapsed_ms
        pre                     = $vr.pre
        post                    = $vr.post
        target_still_foreground = $vr.target_still_foreground
        effect_observed         = $vr.effect_observed
        failure_reason          = $vr.failure_reason
        action_error            = $vr.action_error
    }
    if ($requireVerified -and -not $vr.verified) {
        return @{ ok = $false; error_code = 'DRAG_NO_EFFECT'; error_message = "Drag from ($fx,$fy) to ($tx,$ty) completed but target window bounds did not change within 1600ms poll ladder"; result = $diag; evidence = $diag }
    }
    return @{ ok = $true; result = $diag; evidence = $diag }
}

function Tool-Inspect($a) {
    # Try UIA first; fall back to Win32 metrics (foreground window bounds).
    # P0-R6 (0.4.4): honor `max_depth` from the schema — bounded descent that
    # collects up to 3 direct/nested children so callers can see the local
    # subtree. Echoing `max_depth` also proves the parameter is actually bound
    # (the 0.4.3 `$args` shadowing regression would have surfaced $null here).
    $x = if ($a.PSObject.Properties['x']) { [int]$a.x } else { $null }
    $y = if ($a.PSObject.Properties['y']) { [int]$a.y } else { $null }
    $hnd = if ($a.window_handle) { [string]$a.window_handle } else { $null }
    $maxDepth = if ($a.PSObject.Properties['max_depth'] -and $a.max_depth) { [int]$a.max_depth } else { 4 }
    if ($maxDepth -lt 1) { $maxDepth = 1 } elseif ($maxDepth -gt 8) { $maxDepth = 8 }
    try {
        $auto = [System.Windows.Automation.AutomationElement]
        $el = $null
        if ($x -ne $null -and $y -ne $null) {
            $pt = New-Object System.Windows.Point $x, $y
            $el = $auto::FromPoint($pt)
        } elseif ($hnd) {
            $el = $auto::FromHandle([IntPtr]::new([int64]$hnd))
        } else {
            $el = $auto::FocusedElement
        }
        if ($null -ne $el) {
            $current = $el.Current
            $rect = $current.BoundingRectangle
            # Bounded child descent — cap total collected nodes to keep the
            # response small regardless of max_depth.
            $children = @()
            try {
                $walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
                $stack = New-Object System.Collections.Stack
                $child = $walker.GetFirstChild($el)
                while ($null -ne $child -and $children.Count -lt 3) {
                    $cc = $child.Current
                    $children += @{ name = $cc.Name; control_type = $cc.ControlType.ProgrammaticName }
                    $child = $walker.GetNextSibling($child)
                }
            } catch { Log "[inspect] child walk failed: $($_.Exception.Message)" }
            # 0.4.15: For Document/Edit control types, extract the actual
            # readable text via TextPattern.DocumentRange.GetText(-1) and/or
            # ValuePattern.Current.Value. Direct tool result carries the
            # plaintext (this IS the caller's requested read); the event log
            # is redacted to length + sha256 by redactDesktopResult.
            $ctrlType = $current.ControlType.ProgrammaticName
            $isDocOrEdit = ($ctrlType -match '\.Document$' -or $ctrlType -match '\.Edit$')
            $textVal = $null; $valueVal = $null
            if ($isDocOrEdit) {
                try {
                    $tpId = [System.Windows.Automation.TextPattern]::Pattern
                    $tp = $null
                    if ($el.TryGetCurrentPattern($tpId, [ref]$tp)) {
                        $textVal = $tp.DocumentRange.GetText(-1)
                    }
                } catch { Log "[inspect] TextPattern read failed: $($_.Exception.Message)" }
                try {
                    $vpId = [System.Windows.Automation.ValuePattern]::Pattern
                    $vp = $null
                    if ($el.TryGetCurrentPattern($vpId, [ref]$vp)) {
                        $valueVal = $vp.Current.Value
                    }
                } catch { Log "[inspect] ValuePattern read failed: $($_.Exception.Message)" }
            }
            return @{
                ok = $true; result = @{
                    source = 'uia'
                    name = $current.Name
                    control_type = $ctrlType
                    class_name = $current.ClassName
                    is_enabled = $current.IsEnabled
                    is_offscreen = $current.IsOffscreen
                    bounds = @{ x = [int]$rect.X; y = [int]$rect.Y; w = [int]$rect.Width; h = [int]$rect.Height }
                    max_depth = $maxDepth
                    children = $children
                    is_document_or_edit = $isDocOrEdit
                    text = $textVal
                    value = $valueVal
                    text_length = if ($textVal)  { $textVal.Length }  else { 0 }
                    value_length = if ($valueVal) { $valueVal.Length } else { 0 }
                }
            }
        }
    } catch {
        Log "[inspect] uia failed: $($_.Exception.Message)"
    }
    # Win32 fallback: foreground window metrics.
    $fg = [SI]::GetForegroundWindow()
    $r = New-Object SI+RECT
    [void][SI]::GetWindowRect($fg, [ref]$r)
    $sb = New-Object System.Text.StringBuilder 256
    [void][SI]::GetWindowText($fg, $sb, 256)
    return @{
        ok = $true; result = @{
            source = 'win32'
            name = $sb.ToString()
            window_handle = "$($fg.ToInt64())"
            bounds = @{ x = $r.L; y = $r.T; w = ($r.R - $r.L); h = ($r.B - $r.T) }
            max_depth = $maxDepth
        }
    }
}



function Write-SessionDoc($doc) {
    # BOM-less UTF-8 is required: helper/src/desktop.mjs does JSON.parse(readFile(...,"utf8"))
    # and JSON.parse rejects a leading BOM. Set-Content -Encoding UTF8 (WinPS 5.1) emits a BOM.
    # Write atomically via a UNIQUE same-directory temp file so:
    #   * heartbeat readers cannot observe a partial write
    #   * concurrent publishes cannot collide on a shared .tmp name
    # Guarantee cleanup of BOTH the staging temp AND the backup replaced by
    # File.Replace in a finally block if either survived the publish.
    #
    # WinPS 5.1 / .NET Framework: `File.Replace($tmp, $sessionFile, $null)`
    # throws "The given path's format is not supported." because the null
    # backup arg is coerced to an invalid path. Provide a REAL same-directory
    # backup path and delete it in finally. Never accept $null here.
    $stamp = $PID.ToString() + "." + ([guid]::NewGuid().ToString('N'))
    $tmp    = Join-Path $sentinelDir ("desktop-session." + $stamp + ".tmp")
    $backup = Join-Path $sentinelDir ("desktop-session." + $stamp + ".bak")
    try {
        $json = ($doc | ConvertTo-Json)
        [System.IO.File]::WriteAllText($tmp, $json, [System.Text.UTF8Encoding]::new($false))
        if (Test-Path $sessionFile) {
            # Non-null $backup keeps WinPS 5.1 happy AND lets us re-secure the
            # displaced document before removing it (fail-closed on ACL failure).
            [System.IO.File]::Replace($tmp, $sessionFile, $backup)
        } else {
            [System.IO.File]::Move($tmp, $sessionFile)
        }
        # Re-apply owner-only ACL on EVERY publish. File.Replace on WinPS 5.1
        # is not guaranteed to preserve the destination ACL (behaviour varies
        # by filesystem/OS build). Re-asserting the same rule the initial
        # publish set is cheap and idempotent, and never touches the bearer
        # secret (icacls only sees the file path).
        Set-OwnerOnlyAcl $sessionFile
    } finally {
        if (Test-Path $tmp) {
            try { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue } catch {}
        }
        if (Test-Path $backup) {
            # Backup briefly contains the previous session doc (bearer secret).
            # Re-assert owner-only ACL best-effort, then delete. If ACL fails
            # here we still delete the file so no residue survives on disk.
            try { & icacls $backup /inheritance:r /grant:r "${ownerPrincipal}:(F)" | Out-Null } catch {}
            try { Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
}

function Invoke-FatalSessionInvalidate([string]$reason) {
    # Fail-closed: an ACL enforcement failure (or any other Write-SessionDoc
    # failure after a publish) means the published desktop-session.json may
    # be unreadable to the Helper OR readable to OTHER local users. Either
    # way we MUST stop advertising an ACTIVE session and stop serving
    # authenticated requests immediately.
    #
    # 1. Flip the abort flag so the main loop exits at its next check.
    # 2. Stop the HttpListener so no further authenticated request is served.
    # 3. Best-effort remove the published session file so no fresh caller
    #    can discover the bridge (readers get DESKTOP_SESSION_INACTIVE).
    #
    # We NEVER log the bearer secret or session file contents - only the
    # short reason string, which comes from icacls/system error text and
    # does not contain the secret.
    $script:AbortRequested = $true
    Log "[fatal] $reason - invalidating desktop session"
    try {
        if ($null -ne $script:http -and $script:http.IsListening) {
            $script:http.Stop()
        }
    } catch {}
    try {
        if (Test-Path $sessionFile) {
            Remove-Item -Force $sessionFile -ErrorAction SilentlyContinue
        }
    } catch {}
}

function Bump-Activity() {
    $script:LastActivityAt = [DateTime]::UtcNow
    # Read/parse of the current session doc is best-effort (external races
    # with restart/repair are non-fatal). Re-publishing MUST fail closed so
    # a Set-OwnerOnlyAcl failure cannot leave the bridge ACTIVE with an
    # unreadable or over-permissive session file. NEVER swallow the ACL
    # exception with a bare `catch {}`.
    $doc = $null
    try {
        $doc = Get-Content $sessionFile -Raw | ConvertFrom-Json
        $ms = [int64](($script:LastActivityAt) - (Get-Date '1970-01-01').ToUniversalTime()).TotalMilliseconds
        $doc.last_activity_at = $ms
    } catch {
        return
    }
    try {
        Write-SessionDoc $doc
    } catch {
        Invoke-FatalSessionInvalidate "Bump-Activity: session republish failed: $($_.Exception.Message)"
    }
}

$script:LastActivityAt = [DateTime]::UtcNow

# Idempotency journal: composite key -> stored result (JSON on disk).
$journalDir = Join-Path $sentinelDir "desktop-journal-$sessionId"
function Journal-Key($body) {
    # P0-R5 0.4.1: journal identity uses TRUSTED orchestration envelope
    # (run_id + intent_id + orchestrator idempotency_key) PLUS the active
    # local session_id. Never derived from caller-supplied desktop tool
    # arguments, which two different runs can collide on (e.g. both use
    # "att1:seq1" and neither ever sets `session_id` / `idempotency_key`
    # inside `args`). Retrying the SAME intent replays; two different runs
    # execute independently.
    $env = $body.envelope
    $runId    = if ($env -and $env.run_id)          { [string]$env.run_id }          else { '' }
    $intentId = if ($env -and $env.intent_id)       { [string]$env.intent_id }       else { '' }
    $idem     = if ($env -and $env.idempotency_key) { [string]$env.idempotency_key } else { '' }
    $composite = "$sessionId|$runId|$intentId|$idem"
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($composite)
    $sha = [System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes)
    return -join ($sha | ForEach-Object { $_.ToString('x2') })
}

function Dispatch-Tool($body) {
    switch ($body.tool) {
        'desktop_wait'          { return Tool-Wait $body.args }
        'desktop_snapshot'      { return Tool-Snapshot $body.args }
        'desktop_list_windows'  { return Tool-ListWindows $body.args }
        'desktop_focus_window'  { return Tool-FocusWindow $body.args }
        'desktop_click'         { return Tool-Click $body.args }
        'desktop_type'          { return Tool-Type $body.args }
        'desktop_clipboard_get' { return Tool-ClipboardGet $body.args }
        'desktop_clipboard_set' { return Tool-ClipboardSet $body.args }
        'desktop_launch'        { return Tool-Launch $body.args }
        'desktop_press'         { return Tool-Press $body.args }
        'desktop_hotkey'        { return Tool-Hotkey $body.args }
        'desktop_scroll'        { return Tool-Scroll $body.args }
        'desktop_drag'          { return Tool-Drag $body.args }
        'desktop_inspect'       { return Tool-Inspect $body.args }
        default                 { return @{ ok = $false; error_code = 'TOOL_UNKNOWN'; error_message = "no impl for $($body.tool)" } }
    }
}

# ---------- HTTP listener lifecycle ----------
# A probe socket is used only to ask Windows for a candidate loopback port.
# It MUST be fully released before HttpListener attempts to bind that port.
$script:http = $null
$script:AbortRequested = $false
$probeListener = $null
$port = $null
$maxBindAttempts = 5

try {
    for ($bindAttempt = 1; $bindAttempt -le $maxBindAttempts; $bindAttempt++) {
        try {
            $probeListener = New-Object System.Net.Sockets.TcpListener ([System.Net.IPAddress]::Loopback), 0
            $probeListener.Start()
            $port = ([System.Net.IPEndPoint]$probeListener.LocalEndpoint).Port
        } finally {
            if ($null -ne $probeListener) {
                try { $probeListener.Stop() } catch {}
                try { $probeListener.Server.Dispose() } catch {}
                $probeListener = $null
            }
        }

        try {
            $script:http = New-Object System.Net.HttpListener
            $script:http.Prefixes.Add("http://127.0.0.1:$port/")
            $script:http.Start()
            break
        } catch {
            $bindError = $_
            if ($null -ne $script:http) {
                try { $script:http.Stop() } catch {}
                try { $script:http.Close() } catch {}
                $script:http = $null
            }
            if ($bindAttempt -ge $maxBindAttempts) { throw $bindError }
            Start-Sleep -Milliseconds (100 * $bindAttempt)
        }
    }

    if ($null -eq $script:http -or -not $script:http.IsListening) {
        throw "Desktop Operator could not bind a loopback HTTP listener after $maxBindAttempts attempts."
    }

    # ACTIVE state is published only after the authenticated HTTP bridge is listening.
    $now = [int64]((Get-Date).ToUniversalTime() - (Get-Date '1970-01-01')).TotalMilliseconds
    $sessionDoc = [ordered]@{
        session_id       = $sessionId
        port             = $port
        secret           = $secret
        worker_id        = $workerId
        started_at       = $now
        last_activity_at = $now
        idle_ttl_ms      = ($IdleTtlSeconds * 1000)
        log_path         = $logPath
    }
    Write-SessionDoc $sessionDoc
    # Restrict to current user with FULL control (needs Delete/Modify to
    # remove/rewrite session file on restart) and REVOKE inherited ACEs so
    # other local users cannot read the bearer secret. (F) = Full Control =
    # Read + Write + Delete + Modify (fixes prior R/W-only Remove-Item denial).
    Set-OwnerOnlyAcl $sessionFile
    # PID file MUST be plain ASCII (no BOM) so cmd.exe `set /p` in
    # stop-desktop-operator.bat reads a clean numeric PID.
    [System.IO.File]::WriteAllText($pidFile, "$PID", [System.Text.UTF8Encoding]::new($false))
    New-Item -ItemType Directory -Path $journalDir | Out-Null


    Log "[desktop-operator] listening on http://127.0.0.1:$port"
    Log "[desktop-operator] ACTIVE session=$sessionId port=$port ttl=${IdleTtlSeconds}s log=$logPath"
    Write-Host ""
    Write-Host "==================================================================="
    Write-Host " Sentinel OS Desktop Operator - ACTIVE"
    Write-Host "   session_id : $sessionId"
    Write-Host "   port       : 127.0.0.1:$port (loopback only)"
    Write-Host "   log        : $logPath"
    Write-Host "   idle TTL   : ${IdleTtlSeconds}s"
    Write-Host " Stop with:  helper\stop-desktop-operator.bat"
    Write-Host "==================================================================="
    Write-Host ""

    # P0-R5 0.4.1: only ONE pending GetContextAsync task at any time. Creating
    # a fresh task every 5-second idle-poll timeout leaked the previous task,
    # and a real request that arrived later could be consumed by an abandoned
    # task while the current task never completed -> DESKTOP_BRIDGE_TIMEOUT
    # after 20s. We keep the single task alive across polling intervals and
    # only null it out after successful completion.
    $ctxTask = $null
    while ($script:http.IsListening) {
        if ($script:AbortRequested) {
            Log "[desktop-operator] abort requested - exiting main loop."
            break
        }
        if (([DateTime]::UtcNow - $script:LastActivityAt).TotalSeconds -gt $IdleTtlSeconds) {
            Log "[desktop-operator] idle TTL exceeded - exiting."
            break
        }
        if ($null -eq $ctxTask) {
            $ctxTask = $script:http.GetContextAsync()
        }
        if (-not $ctxTask.Wait(5000)) { continue }
        $ctx = $ctxTask.Result
        $ctxTask = $null
        $req = $ctx.Request; $res = $ctx.Response
        $res.ContentType = 'application/json; charset=utf-8'
        $res.Headers['Cache-Control'] = 'no-store'

        $auth = $req.Headers['Authorization']
        if (-not $auth -or $auth -ne "Bearer $secret") {
            $res.StatusCode = 401
            $b = ([System.Text.Encoding]::UTF8.GetBytes('{"ok":false,"error_code":"UNAUTHORIZED"}'))
            $res.OutputStream.Write($b, 0, $b.Length); $res.Close(); continue
        }
        if ($req.RemoteEndPoint.Address.ToString() -notin @('127.0.0.1', '::1')) {
            $res.StatusCode = 403
            $b = ([System.Text.Encoding]::UTF8.GetBytes('{"ok":false,"error_code":"LOOPBACK_ONLY"}'))
            $res.OutputStream.Write($b, 0, $b.Length); $res.Close(); continue
        }

        try {
            $reader = New-Object System.IO.StreamReader($req.InputStream, [System.Text.Encoding]::UTF8)
            $bodyText = $reader.ReadToEnd()
            $body = $bodyText | ConvertFrom-Json

            $jkey = Journal-Key $body
            $jfile = Join-Path $journalDir "$jkey.json"
            if (Test-Path $jfile) {
                $prev = Get-Content $jfile -Raw
                $b = [System.Text.Encoding]::UTF8.GetBytes($prev)
                $res.StatusCode = 200
                $res.OutputStream.Write($b, 0, $b.Length); $res.Close(); continue
            }

            $result = Dispatch-Tool $body
            $payload = $result | ConvertTo-Json -Depth 10 -Compress
            Set-Content -Path $jfile -Value $payload -Encoding UTF8
            $b = [System.Text.Encoding]::UTF8.GetBytes($payload)
            $res.StatusCode = if ($result.ok) { 200 } else { 400 }
            $res.OutputStream.Write($b, 0, $b.Length); $res.Close()
            Bump-Activity
            Log "[tool] $($body.tool) ok=$($result.ok)"
        } catch {
            Log "[error] $($_.Exception.Message)"
            try {
                $err = @{ ok = $false; error_code = 'BRIDGE_EXCEPTION'; error_message = $_.Exception.Message } | ConvertTo-Json -Compress
                $b = [System.Text.Encoding]::UTF8.GetBytes($err)
                $res.StatusCode = 500
                $res.OutputStream.Write($b, 0, $b.Length); $res.Close()
            } catch {}
        }
    }
} finally {
    if ($null -ne $probeListener) {
        try { $probeListener.Stop() } catch {}
        try { $probeListener.Server.Dispose() } catch {}
        $probeListener = $null
    }
    if ($null -ne $script:http) {
        try { $script:http.Stop() } catch {}
        try { $script:http.Close() } catch {}
        $script:http = $null
    }
    if (Test-Path $sessionFile) { Remove-Item -Force $sessionFile }
    if (Test-Path $pidFile)     { Remove-Item -Force $pidFile }
    if (Test-Path $journalDir)  { Remove-Item -Recurse -Force $journalDir }
    Log "[desktop-operator] STOPPED"
}
